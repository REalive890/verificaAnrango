var N1,N2;
var tabellaCreata=false;
var figura;
var cella;
var punti=0;
var timer15;
var finito=false;
function prove()
{

    // console.log(document.querySelector("body fieldset div select").value)

    // console.log(document.querySelector("body fieldset div select option").innerHTML)

    // console.log(document.querySelector("input:nth-of-type(1)").innerHTML)
    // console.log(document.querySelector("input:nth-of-type(2)").value)
    console.log(document.querySelector("body>section"))
    N1=5
    N2=6
//

//
}
function creazioneGrigliaDinamica()
{
    let BoxGriglia=document.querySelector("body>section");

    let griglia="<table>"
    for (let i = 0; i < N1; i++) {
        griglia+="<tr>"
        for (let j = 0; j < N2; j++) {
            griglia+=`<td onclick="cancella(event)"></td>`
        }
        griglia+="</tr>"
    }
    griglia+="</table>"

    BoxGriglia.innerHTML=griglia
}
function creareGriglia()
{
     N1=document.querySelector("input:nth-of-type(1)").value;
     N2=document.querySelector("input:nth-of-type(2)").value;
    console.log(N1+"  "+N2)
    if(document.querySelector("body fieldset div select").value!=document.querySelector("body fieldset div select option").innerHTML)
    {
        if(N1>=3&&N1<=6)
        {
            if(N2>=3&&N2<=6)
            {
                
                creazioneGrigliaDinamica();
    tabellaCreata=true;


            }
            else alert("Seconda dimensione della griglia non valida")
        }
        else alert("Prima dimensione della griglia non valida")
    }else alert("Nesun animale selezionato")
}

function giochiamo()
{
    if(tabellaCreata){
        console.log("tabella creata")
        timer15=0;
        let testo
       
        testo=document.querySelector("body fieldset div select").value
        if(testo.includes("🦁")) figura="🦁" 
        else
        if(testo.includes("🦊")) figura="🦊" 
        else
        if(testo.includes("🐥")) figura="🐥" 
        else
        if(testo.includes("🐸")) figura="🐸"
            
        console.log(figura)

       
        setInterval(inserireFigura,3000);
        setInterval(cancellareFigura,1000);
    } else alert("Creare la teballa prima")
}
function inserireFigura()
{
    if(timer15<15000){
        timer15+=3000;
        cella=document.querySelector(`body>section table tr:nth-child(${Math.round(Math.random()*(N1-1)+1)}) td:nth-child(${Math.round(Math.random()*(N2-1)+1)})`);
        console.log(cella)
        
        cella.innerHTML=figura;

    }else if(finito==false){
        clearInterval(setInterval(inserireFigura))
        let nomeUtente=prompt("Gioco terminato. Scrivere il nome Utente:");
        if(punti>0)
        {
            alert(`${nomeUtente} hai totalizzato ${punti} punti. `)
console.log(`${nomeUtente} hai totalizzato ${punti} punti. `)
        }
        else
        {
            alert(`Mi spiace ${nomeUtente}, non sei riuscito a catturare nessun animaletto`)
            console.log(`Mi spiace ${nomeUtente}, non sei riuscito a catturare nessun animaletto`)
        }
        finito=true;
        
    }
}
function cancellareFigura()
{
    clearInterval(setInterval(cancellareFigura))

    cella=document.querySelector(`body>section table tr:nth-child(${Math.round(Math.random()*(N1-1)+1)}) td:nth-child(${Math.round(Math.random()*(N2-1)+1)})`);
        cella.innerHTML="";
}

function cancella(event)
{
    console.log(event.srcElement.innerHTML)
    console.log(document.querySelector("body>header h4"))
    if(event.srcElement.innerHTML!="")  {
        event.srcElement.innerHTML=""
        punti++;
        document.querySelector("body>header h4").innerHTML=`Pt. ${punti}`
    }
}