# Verifica di TPSIT su javascript - Acchiappa gli animali

## Obiettivo

## Requisiti
- Alla pressione del tasto Crea è necessario prelevare l'emoji dell'animale scelto e verificare che la grandezza della griglia sia almeno 3x3 e non superiore a 6x6 altrimenti presentare errore. Dopo aver fatto le opportune verifiche pulire la sezione e creare una nuova tabella vuota dinamicamente (seguendo la struttura presentata come esempio) con la dimensione indicata dall'utente. (pt 2.5)
- Alla pressione del tasto Gioca controllare se è stata creata la tabella e poi avviare un timer che ogni 3 secondi mostra l'animale scelto in una cella diversa per 1 secondo. (pt 2.5)
- In quel secondo in cui l'animale è visibile l'utente deve poterci cliccare e guadagnare un punto se ha cliccato quando era ancora visibile. Il punto deve essere visualizzato nel h4 in alto a destra. (pt 2)
- Dopo 15 secondi terminare il gioco, chiedere da javascript il nome all'utente e stampare il risultato (es. "Giacomo hai totalizzato 5 punti. " se il punteggio + positivo, "Mi spiace Giacomo, non sei riuscito a catturare nessun animaletto") sia su console, sia con una finestrella da javascript. (pt 1)

## Esoneri
Chi ha accesso al tempo aggiuntivo in questa verifica sarà esonerato dalla gestione della select e della richiesta delle dimensioni della griglia, dovrà creare dinamicamente una tabella 3x3 e usare un animale a sua scelta. 
